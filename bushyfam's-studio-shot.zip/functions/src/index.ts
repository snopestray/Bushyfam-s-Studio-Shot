import * as functions from "firebase-functions";
import { GoogleGenAI, Modality } from "@google/genai";
import * as cors from "cors";

// Initialize CORS middleware
const corsHandler = cors({ origin: true });

// Access the API key from Firebase environment configuration
// You must set this using the Firebase CLI:
// firebase functions:config:set gemini.key="YOUR_API_KEY"
const ai = new GoogleGenAI({ apiKey: functions.config().gemini.key });

export const transform = functions.https.onRequest(async (req, res) => {
  // Handle CORS for preflight and actual requests
  corsHandler(req, res, async () => {
    // Only allow POST requests
    if (req.method !== "POST") {
      res.setHeader("Allow", ["POST"]);
      res.status(405).json({ message: `Method ${req.method} Not Allowed` });
      return;
    }

    try {
      const { image, mimeType } = req.body;

      if (!image || !mimeType) {
        res.status(400).json({ message: "Missing image data or mimeType." });
        return;
      }

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-image-preview",
        contents: {
          parts: [
            {
              inlineData: {
                data: image,
                mimeType: mimeType,
              },
            },
            {
              text: "Transform this product photo into a professional, studio-quality image for an e-commerce website. Replace the background with a clean, light gray studio background (#f0f0f0). Enhance the lighting, color balance, and sharpness to make the product look appealing and high-quality. Do not add any text, watermarks, or other objects.",
            },
          ],
        },
        config: {
            responseModalities: [Modality.IMAGE, Modality.TEXT],
        },
      });
      
      const imagePart = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
      const newImageBase64 = imagePart?.inlineData?.data;

      if (newImageBase64) {
        res.status(200).json({ image: newImageBase64 });
      } else {
        const errorText = response.text || "No image data returned from API.";
        console.error("Gemini API did not return an image. Response:", errorText);
        res.status(500).json({ message: `Image generation failed. Model response: ${errorText}` });
      }
      
    } catch (error) {
      console.error("Error in Firebase function:", error);
      const message = error instanceof Error ? error.message : "An internal server error occurred.";
      res.status(500).json({ message });
    }
  });
});
