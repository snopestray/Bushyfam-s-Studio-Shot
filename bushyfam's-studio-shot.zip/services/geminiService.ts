/**
 * CRITICAL SECURITY REFACTOR:
 * This function no longer communicates with the Gemini API directly.
 * Instead, it now sends the image data to a secure backend endpoint `/api/transform`.
 * Your API key MUST be used in that backend endpoint, never in the frontend code.
 * This prevents users from stealing your API key.
 *
 * @param base64ImageData The base64 encoded string of the image.
 * @param mimeType The MIME type of the image.
 * @returns A promise that resolves to the base64 encoded string of the transformed image, received from your backend.
 */
export const transformImage = async (base64ImageData: string, mimeType: string): Promise<string> => {
  // !!! IMPORTANT !!!
  // AFTER DEPLOYING TO FIREBASE, REPLACE THIS URL WITH YOUR ACTUAL CLOUD FUNCTION URL.
  // It will look something like: https://transform-abcdef.a.run.app or
  // https://<your-region>-<your-project-id>.cloudfunctions.net/transform
  const functionUrl = 'https://<YOUR_CLOUD_FUNCTION_URL_HERE>/transform';

  if (functionUrl.includes('<YOUR_CLOUD_FUNCTION_URL_HERE>')) {
    throw new Error('Please update the functionUrl in services/geminiService.ts with your actual Firebase Cloud Function URL.');
  }
  
  try {
    const response = await fetch(functionUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        image: base64ImageData,
        mimeType: mimeType,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: response.statusText }));
      throw new Error(errorData.message || `Request failed with status ${response.status}`);
    }

    const data = await response.json();

    if (data.image) {
      return data.image;
    } else {
      throw new Error(data.message || 'Backend did not return an image.');
    }

  } catch (error) {
    console.error("Error calling backend service:", error);
    if (error instanceof Error) {
      throw new Error(`Service Error: ${error.message}`);
    }
    throw new Error('An unknown error occurred while transforming the image.');
  }
};